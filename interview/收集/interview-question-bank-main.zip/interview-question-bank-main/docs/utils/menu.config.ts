// 默认路由表
export default [
  { text: "html", link: "/html" },
  { text: "css", link: "/css" },
  { text: "js", link: "/js" },
  { text: "ts", link: "/ts" },
  { text: "vue2", link: "/vue2" },
  { text: "vue3", link: "/vue3" },
  { text: "react", link: "/react" },
  { text: "node", link: "/node" },
  { text: "http", link: "/http" },
  { text: "场景题", link: "/scenario-based" },
  { text: "前端工程化", link: "/fe-engineering" },
  { text: "手写题", link: "/code" },
];
